java --module-path lib/ --add-modules javafx.controls,javafx.fxml -jar Gsis-0.2.jar
