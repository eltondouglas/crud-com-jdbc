Para executar o sistema siga as orientações abaixo:

Crie um arquivo .sh ou adicione uma entrada no menu com o nome qua você preferir.

adicione a linha a seguir para executar o sistema

java --module-path caminho_do_modulo --add-module pacotes -jar nomedojar.jar

Ex: java --module-path lib/ --add-module javafx.controls,javafx.fxml

by: Generatebit - Heysenward
